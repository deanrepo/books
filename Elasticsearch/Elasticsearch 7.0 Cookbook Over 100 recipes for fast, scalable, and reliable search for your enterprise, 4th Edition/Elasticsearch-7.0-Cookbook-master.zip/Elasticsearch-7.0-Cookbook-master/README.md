# Elasticsearch-7.0-Cookbook-Fourth-Edition
Elasticsearch 7.0 Cookbook, Fourth Edition, published by packt publishing
